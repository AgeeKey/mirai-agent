#!/bin/bash

flutter build web --base-href /app/